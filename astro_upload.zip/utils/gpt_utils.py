import openai, os
from dotenv import load_dotenv
load_dotenv()
openai.api_key = os.getenv("OPENAI_API_KEY")

def generate_forecast(chart_summary, area="General"):
    prompt = f"Based on this birth chart:\n{chart_summary}\nGive a {area} forecast for this week."
    response = openai.ChatCompletion.create(model="gpt-4", messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content

def ask_astro_gpt(chart_summary, user_question):
    prompt = f"The user's birth chart is:\n{chart_summary}\nThey ask: {user_question}\nAnswer with astrology-based insights."
    response = openai.ChatCompletion.create(model="gpt-4", messages=[{"role": "user", "content": prompt}])
    return response.choices[0].message.content
