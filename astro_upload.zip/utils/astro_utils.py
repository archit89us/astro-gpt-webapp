from flatlib.chart import Chart
from flatlib.datetime import Datetime
from flatlib.geopos import GeoPos
from flatlib import const
from geopy.geocoders import Nominatim

def get_lat_lon(place):
    geolocator = Nominatim(user_agent="astro_app")
    location = geolocator.geocode(place)
    return (location.latitude, location.longitude) if location else (0.0, 0.0)

def generate_natal_chart(name, dob, tob, place):
    lat, lon = get_lat_lon(place)
    dt = Datetime(dob.strftime('%Y-%m-%d'), tob.strftime('%H:%M'), '+00:00')
    pos = GeoPos(str(lat), str(lon))
    chart = Chart(dt, pos)
    summary = [f"Name: {name}", f"Date: {dob}", f"Time: {tob}", f"Place: {place}"]
    for obj in [const.SUN, const.MOON, const.MERCURY, const.VENUS, const.MARS, const.JUPITER, const.SATURN, const.URANUS, const.NEPTUNE, const.PLUTO, const.ASC, const.MC]:
        planet = chart.get(obj)
        summary.append(f"{obj}: {planet.sign} in House {planet.house}")
    return "\n".join(summary)
